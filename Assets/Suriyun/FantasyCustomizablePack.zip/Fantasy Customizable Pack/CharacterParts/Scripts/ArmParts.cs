﻿using UnityEngine;
using System.Collections;

public class ArmParts
{
    public GameObject shoulder;
    public GameObject elbow;
}
