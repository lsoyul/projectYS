﻿using UnityEngine;
using System.Collections;

public class LegParts
{
    public GameObject hip;
    public GameObject knee;
}
