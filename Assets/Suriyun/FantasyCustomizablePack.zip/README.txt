Update Version 1.5

- Added 12 Weapon,1 Shield,4 Accessories
- Added 1 Sample characters prefab 
- Fix weapon 27

Update V1.4.2
 - Changes shaders to Mobile/Unlit which will be better performance for mobile
 - Fix some invalid materials
 - Add character model class which will be used in Example scene later
 - Add changes all body parts controls

Update V1.4.1
 Add 3 Animations

Update V1.4.0

- disable cast shadows all of resources
- use unlit shader
- delete unitychan shader

*if you want outline,Download latest version of Unitychan shader http://unity-chan.com/

----------------------------------------------
